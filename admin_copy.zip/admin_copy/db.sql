-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 20, 2021 at 05:32 PM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 8.0.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kharidar_api`
--

-- --------------------------------------------------------
--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `user_type`, `bussiness_name`, `img`, `business_card_front_img`, `business_card_back_img`, `business_outdoor_img`, `business_indoor_img`, `long_cords`, `late_cords`, `email`, `email_verified_at`, `verification_code`, `password`, `remember_token`, `address`, `city`, `phone`, `balance`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'buyer', 'Kharidar', 'elon-18954.jpg', '', '', '', '', '73.00000', '74.00000', 'admin@kharidar.co', NULL, NULL, '$2y$10$3ifqpup2r2AiMjFjgTHlROjsur93dUsWW1ykMvFyne4pF.vT8.oAy', NULL, '65 cavalry ground', 'lahore', '042111222333', 0.00, '2021-09-13 12:59:00', '2021-09-13 12:59:00'),
(62, 'yasar abbas', 'seller', 'kalon', '', '', '', '', '', '74.34361', '31.54972', 'yasar.jinsung@gmail.com', NULL, NULL, '$2y$10$rapjtzY6h3pHr/Ejxxsbkei75K3NR2cp2Rt9bgLa8edJZuC.78JbK', NULL, 'address', 'city', '03004931119', 0.00, '2021-09-16 07:06:45', '2021-09-16 07:06:45'),
(66, 'faisal shah', 'buyer', 'ddf', '', '', '', '', '', '74.34361', '31.54972', 'kh.faisal@hotmail.com', NULL, NULL, '$2y$10$.h3l7IMigR3wKcw1xh03l.SBx09OIhlICPZE2eSKopbJS9SM4IbEm', NULL, NULL, NULL, '03402222211', 0.00, '2021-09-18 15:13:30', '2021-09-18 15:13:30'),
(67, 'ewrewrrerw', 'buyer', 'ddf', '', '', '', '', '', '74.34361', '31.54972', 'qweqwewqeew@gmail.com', NULL, NULL, '$2y$10$JVnLIVtsDcHg0GkLEBwT2eRIns5LU4ShaxGz1A53WmgXKzWprEDGK', NULL, NULL, NULL, '79379379397', 0.00, '2021-09-20 09:46:14', '2021-09-20 09:46:14');

-- --------------------------------------------------------

ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=68;

