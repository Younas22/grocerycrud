@include('admin.template.header')

@yield('content')

{{--<div style="padding: 20px">--}}
{{--    {!! $output !!}--}}
{{--</div>--}}
@include('admin.template.footer')
