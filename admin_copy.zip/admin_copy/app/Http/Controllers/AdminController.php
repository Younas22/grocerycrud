<?php

namespace App\Http\Controllers;
use App\Http\Controllers\GCurdController;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use DB;

class AdminController extends Controller
{


    public function __construct()
    {
        $this->GCurdController = new GCurdController();
    }

    public function index()
{
        $crud = $this->GCurdController->_getGroceryCrudEnterprise();
        $crud->setTable('categories');
        $crud->setSubject('categories', 'categories');
        $crud->columns(['image','name']);
        $crud->setFieldUpload('image', 'public/uploads/users', env('APP_URL').'/public/uploads/users');

        $crud->callbackColumn('img', function ($value, $row) {
            // show image
            if (empty($value)) {
                $img = "<div class='zoom'><img src='" . url('/public/uploads/no_img.jpg') ."' /></div>";
            }else {
                $img = "<div class='zoom'><img src='" . url('/public/uploads/users') . "/" . $value . "' /></div>";
            }
            return($img);
        });


        $crud->setSkin('bootstrap-v4');
        $output = $crud->render();
        return $this->GCurdController->show($output);
    }
}