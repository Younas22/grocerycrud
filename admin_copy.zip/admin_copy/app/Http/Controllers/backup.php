<?php

namespace App\Http\Controllers;
use App\Http\Controllers\GCurdController;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use DB;

class AdminController extends Controller
{


    public function __construct()
    {
        $this->GCurdController = new GCurdController();
    }

    public function index()
{
        $crud = $this->GCurdController->_getGroceryCrudEnterprise();
        $crud->setTable('products');
        $crud->setSubject('products', 'products');
        $crud->columns(['name','desc']);
         $crud->setFieldUpload('desc', 'public/uploads/users', env('APP_URL').'/public/uploads/users');

        // $crud->callbackUpload(function ($test1 = null) {
        //     var_dump($test1);
        //     var_dump($_FILES);

        //     return false;
        // });



       // $crud->callbackAddField('desc',array($this, 'add_upload_fied'));


       // $crud->callbackAfterInsert(function ($row) {
            // $files = array();
            // if (!empty($this->files))
            // {
            //     foreach ($this->files as $file)
            //     {
            //         $files[] = array($this->category_id_field => $row, 'image' => $file);
            //     }
            // }
            // DB::table($this->file_table)->insert(['image'=>'a']);
            // return $row;

            // echo "<br>";
            // print_r($row);

       // });


        $crud->setSkin('bootstrap-v4');
        //  $crud->unsetFields(['updated_at','created_at']);
        // $crud->requiredFields(['candidate_name', 'father_name']);
        $output = $crud->render();
        return $this->GCurdController->show($output);
    }


    //     function add_upload_fied()
    // {
    //         $html = '<div>
    //                 <span>Upload a file</span>
    //                 <input type="file" name="files[]" multiple="multiple">
    //                 </div>';

    //         return $html;
    // }



 
    // function _save_files_into_db($post_array, $primary_key)
    // {
    //     // $this->db->delete($this->file_table, array($this->category_id_field => $primary_key));

    //     DB::table($this->file_table)->delete(array($this->category_id_field => $primary_key));

    //     $files = array();
    //     if (!empty($this->files))
    //     {
    //         foreach ($this->files as $file)
    //         {
    //             $files[] = array($this->category_id_field => $primary_key, 'image' => $file);
    //         }
    //     }
    //     if (!empty($files))
    //     {
    //         // $this->db->insert_batch($this->file_table, $files);
    //         DB::table($this->file_table)->insert($files);
    //     }
    //     return true;
    // }

}