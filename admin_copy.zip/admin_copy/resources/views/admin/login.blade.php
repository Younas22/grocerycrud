<!DOCTYPE HTML>
<html lang="en">

<head>
<title>Admin Login</title>
<link rel="shortcut icon" href="uploads/global/favicon.png">
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<meta http-equiv="X-UA-Compatible" content="ie=edge" />
<link rel="stylesheet" href="https://necolas.github.io/normalize.css/latest/normalize.css" />
<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/qaxim/material@1.5/assets/css/style.css" />
<style>
:root {
        --theme-icon: #289d57;
        --theme-bg: #289d57;
        --theme-text: #289d57;
}
</style>
</head>

<body style="background:#ebf0f7">
<div class="contain">



<form class="card" method="POST" action="{{ route('login.custom') }}" style="width: 400px; margin: 0 auto; margin-top: 200px;">
    @csrf
<h2><strong>Login</strong></h2>


<div class="card-body">
        @if (session('errors'))
                <div class="alert alert-success" role="alert">
                        <script>alert("Email or password incorrect")</script>

                </div>
        @endif
    </div>


<label class="filled w100">
    <input type="text" name="email" placeholder=" ">
     @if ($errors->has('email'))
    <span class="text-danger">{{ $errors->first('email') }}</span>
    @endif
    <span>Email</span>
</label>

<label class="filled w100">
    <input type="password" name="password" placeholder=" ">
    @if ($errors->has('password'))
    <span class="text-danger">{{ $errors->first('password') }}</span>
    @endif
    <span>Password</span>
</label>

<button type="submit" class="btn db w100 h50" onclick="loading();">Login</button>
<progress id="loading" style="display:none" class="linear mt-3"/></progress>
</form>

<script>
function loading() {
document.getElementById("loading").style.display = "block";
}
</script>

</div>
</body>
</html>