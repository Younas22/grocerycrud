 
 @include('admin.template.header')
  @yield('content')
 @include('admin.template.footer')
