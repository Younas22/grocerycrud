<aside class="sidebar" style="flex-basis: calc(15%);">
<div class="side-menu bg-wh" role="navigation">
<!--<h3 class="brand">CSS<span> Componnents</span></h3>-->
<ul class="nav__list">
    <li class="main">
        <input id="group-1" type="checkbox" hidden="" <?php if(last(request()->segments()) == "users" AND "sellers" AND "buyers"){echo"checked";}?>>
        <label for="group-1">
            <span>
                <svg class="svg-icon" viewBox="0 0 20 20">
                    <path fill="none" d="M11.611,10.049l-4.76-4.873c-0.303-0.31-0.297-0.804,0.012-1.105c0.309-0.304,0.803-0.293,1.105,0.012l5.306,5.433c0.304,0.31,0.296,0.805-0.012,1.105L7.83,15.928c-0.152,0.148-0.35,0.223-0.547,0.223c-0.203,0-0.406-0.08-0.559-0.236c-0.303-0.309-0.295-0.803,0.012-1.104L11.611,10.049z"></path>
                </svg>
            </span>
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M12 2c-6.627 0-12 5.373-12 12 0 2.583.816 5.042 2.205 7h19.59c1.389-1.958 2.205-4.417 2.205-7 0-6.627-5.373-12-12-12zm-.758 2.14c.256-.02.51-.029.758-.029s.502.01.758.029v3.115c-.252-.027-.506-.042-.758-.042s-.506.014-.758.042v-3.115zm-5.763 7.978l-2.88-1.193c.157-.479.351-.948.581-1.399l2.879 1.192c-.247.444-.441.913-.58 1.4zm1.216-2.351l-2.203-2.203c.329-.383.688-.743 1.071-1.071l2.203 2.203c-.395.316-.754.675-1.071 1.071zm.793-4.569c.449-.231.919-.428 1.396-.586l1.205 2.875c-.485.141-.953.338-1.396.585l-1.205-2.874zm1.408 13.802c.019-1.151.658-2.15 1.603-2.672l1.501-7.041 1.502 7.041c.943.522 1.584 1.521 1.603 2.672h-6.209zm4.988-11.521l1.193-2.879c.479.156.948.352 1.399.581l-1.193 2.878c-.443-.246-.913-.44-1.399-.58zm2.349 1.217l2.203-2.203c.383.329.742.688 1.071 1.071l-2.203 2.203c-.316-.396-.675-.755-1.071-1.071zm2.259 3.32c-.147-.483-.35-.95-.603-1.39l2.86-1.238c.235.445.438.912.602 1.39l-2.859 1.238z"></path></svg>
            <strong>Accounts</strong>
        </label>
        <ul class="menu-list">
            <li><a class="<?php if(last(request()->segments()) == "users"){echo"active";}?>" href="{{url('/admin/users')}}">All Users</a></li>
            <li><a class="<?php if(last(request()->segments()) == "categories"){echo"sellers";}?>"" href="{{url('/admin/sellers')}}">Sellers</a></li>
            <li><a class="<?php if(last(request()->segments()) == "categories"){echo"buyers";}?>"" href="{{url('/admin/buyers')}}">Buyers</a></li>
        </ul>
    </li>
    <li class="main">
        <input id="group-3" type="checkbox" hidden="" <?php if(last(request()->segments()) == "categories" AND "brands" AND "products" AND "industries"){echo"checked";}?>>
        <label for="group-3">
            <span>
                <svg class="svg-icon" viewBox="0 0 20 20">
                    <path fill="none" d="M11.611,10.049l-4.76-4.873c-0.303-0.31-0.297-0.804,0.012-1.105c0.309-0.304,0.803-0.293,1.105,0.012l5.306,5.433c0.304,0.31,0.296,0.805-0.012,1.105L7.83,15.928c-0.152,0.148-0.35,0.223-0.547,0.223c-0.203,0-0.406-0.08-0.559-0.236c-0.303-0.309-0.295-0.803,0.012-1.104L11.611,10.049z"></path>
                </svg>
            </span>
            <svg width="24" height="24" xmlns="http://www.w3.org/2000/svg" fill-rule="evenodd" clip-rule="evenodd"><path d="M1 12.155c2.256 3.97 4.55 7.918 6.879 11.845h-5.379c-.829 0-1.5-.675-1.5-1.5v-10.345zm2.85.859c3.278 1.952 12.866 7.658 13.121 7.805l-5.162 2.98c-.231.132-.49.201-.751.201-.549 0-1.037-.298-1.299-.75l-5.909-10.236zm1.9-12.813c-.23-.133-.489-.201-.75-.201-.524 0-1.026.277-1.299.75l-3.5 6.062c-.133.23-.201.489-.201.749 0 .527.278 1.028.75 1.3 2.936 1.695 14.58 8.7 17.516 10.396.718.413 1.633.168 2.048-.55l3.5-6.062c.133-.23.186-.488.186-.749 0-.52-.257-1.025-.734-1.3l-17.516-10.395m.25 3.944c1.104 0 2 .896 2 2s-.896 2-2 2-2-.896-2-2 .896-2 2-2"></path></svg>
            <strong> Products </strong>
        </label>
        <ul class="menu-list">
            <li><a class="<?php if(last(request()->segments()) == "products"){echo"active";}?>" href="{{url('/admin/products')}}">Products</a></li>
            <li><a class="<?php if(last(request()->segments()) == "categories"){echo"active";}?>" href="{{url('/admin/categories')}}">Categories</a></li>
            <li><a class="<?php if(last(request()->segments()) == "ordering"){echo"active";}?>" href="{{url('/admin/categories/ordering')}}">Categories Order</a></li>
            <li><a class="<?php if(last(request()->segments()) == "brands"){echo"active";}?>"href="{{url('/admin/brands')}}">Brands</a></li>
            <li><a class="<?php if(last(request()->segments()) == "industries"){echo"active";}?>" href="{{url('/admin/industries')}}">Industries</a></li>
        </ul>
    </li>
    <li class="main">
        <input id="group-4" type="checkbox" hidden="">
        <label for="group-4">
            <span>
                <svg class="svg-icon" viewBox="0 0 20 20">
                    <path fill="none" d="M11.611,10.049l-4.76-4.873c-0.303-0.31-0.297-0.804,0.012-1.105c0.309-0.304,0.803-0.293,1.105,0.012l5.306,5.433c0.304,0.31,0.296,0.805-0.012,1.105L7.83,15.928c-0.152,0.148-0.35,0.223-0.547,0.223c-0.203,0-0.406-0.08-0.559-0.236c-0.303-0.309-0.295-0.803,0.012-1.104L11.611,10.049z"></path>
                </svg>
            </span>
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M13.747 12.795l9.253 4.58-3.453 1.32 3.145 4.039-1.547 1.266-3.204-4.104-2.121 3.009-2.073-10.11zm-.747-2.795c0-1.104-.895-2-2-2s-2 .896-2 2 .895 2 2 2 2-.896 2-2zm-2-6c-3.314 0-6 2.686-6 6s2.686 6 6 6c.458 0 .902-.056 1.331-.153l-.403-1.966c-.299.071-.607.119-.928.119-2.206 0-4-1.794-4-4s1.794-4 4-4 4 1.794 4 4c0 .384-.071.747-.173 1.099l1.824.902c.222-.626.349-1.298.349-2.001 0-3.314-2.686-6-6-6zm1.733 13.806c-.559.124-1.137.194-1.733.194-4.411 0-8-3.589-8-8s3.589-8 8-8 8 3.589 8 8c0 1.021-.199 1.994-.549 2.892l1.803.892c.478-1.168.746-2.444.746-3.784 0-5.523-4.477-10-10-10s-10 4.477-10 10 4.477 10 10 10c.733 0 1.446-.084 2.135-.234l-.402-1.96z"></path></svg>
            <strong>Orders & Sales</strong>
        </label>
        <ul class="menu-list">
            <li>
            </li><a href="{{url('/admin/orders/completed')}}">Completed Orders</a>
            <a href="{{url('/admin/orders/pending')}}">Pending Orders</a>
            <li><a href="{{url('/admin/orders/cancelled')}}">Cancelled Orders</a></li>
            <li><a href="{{url('/admin/orders/disputed')}}">Disputed Orders</a></li>
        </ul>
    </li>
    <li class="main">
        <input id="group-5" type="checkbox" hidden="">
        <label for="group-5">
            <span>
                <svg class="svg-icon" viewBox="0 0 20 20">
                    <path fill="none" d="M11.611,10.049l-4.76-4.873c-0.303-0.31-0.297-0.804,0.012-1.105c0.309-0.304,0.803-0.293,1.105,0.012l5.306,5.433c0.304,0.31,0.296,0.805-0.012,1.105L7.83,15.928c-0.152,0.148-0.35,0.223-0.547,0.223c-0.203,0-0.406-0.08-0.559-0.236c-0.303-0.309-0.295-0.803,0.012-1.104L11.611,10.049z"></path>
                </svg>
            </span>
            <svg width="24" height="24" xmlns="http://www.w3.org/2000/svg" fill-rule="evenodd" clip-rule="evenodd"><path d="M17 16h-4v8h-2v-8h-4l5-6 5 6zm7 8h-9v-2h7v-16h-20v16h7v2h-9v-24h24v24z"></path></svg>
            <strong>Reports </strong>
        </label>
        <ul class="menu-list">
            <li>
            </li><li><a href="{{url('/admin/reports/sales')}}">Sales Reports</a></li>
            </li><li><a href="{{url('/admin/reports/payouts')}}">Payouts Reports</a></li>
            </li><li><a href="{{url('/admin/reports/accounts')}}">Accounts Reports</a></li>
        </ul>
    </li>
    <li class="main">
        <input id="group-6" type="checkbox" hidden="">
        <label for="group-6">
            <span>
                <svg class="svg-icon" viewBox="0 0 20 20">
                    <path fill="none" d="M11.611,10.049l-4.76-4.873c-0.303-0.31-0.297-0.804,0.012-1.105c0.309-0.304,0.803-0.293,1.105,0.012l5.306,5.433c0.304,0.31,0.296,0.805-0.012,1.105L7.83,15.928c-0.152,0.148-0.35,0.223-0.547,0.223c-0.203,0-0.406-0.08-0.559-0.236c-0.303-0.309-0.295-0.803,0.012-1.104L11.611,10.049z"></path>
                </svg>
            </span>
            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M14.568.075c2.202 1.174 5.938 4.883 7.432 6.881-1.286-.9-4.044-1.657-6.091-1.179.222-1.468-.185-4.534-1.341-5.702zm7.432 10.925v13h-20v-24h8.409c4.857 0 3.335 8 3.335 8 3.009-.745 8.256-.419 8.256 3zm-16 5h5v-4h-5v4zm12 2h-12v1h12v-1zm0-3h-5v1h5v-1zm0-3h-5v1h5v-1z"></path></svg>
            <strong> POS </strong>
        </label>
        <ul class="menu-list">
            <li>
            </li><li><a href="#">1st level item</a></li>
            <input id="sub-group-3" type="checkbox" hidden="">
            <label for="sub-group-3">
                <span>
                    <svg class="svg-icon" viewBox="0 0 20 20">
                        <path fill="none" d="M11.611,10.049l-4.76-4.873c-0.303-0.31-0.297-0.804,0.012-1.105c0.309-0.304,0.803-0.293,1.105,0.012l5.306,5.433c0.304,0.31,0.296,0.805-0.012,1.105L7.83,15.928c-0.152,0.148-0.35,0.223-0.547,0.223c-0.203,0-0.406-0.08-0.559-0.236c-0.303-0.309-0.295-0.803,0.012-1.104L11.611,10.049z"></path>
                    </svg>
                </span>
                Second level
            </label>
            <ul class="sub-menu-list">
                <li><a href="#">2nd level nav item</a></li>
                <li><a href="#">2nd level nav item</a></li>
                <li><a href="#">2nd level nav item</a></li>
                <li>
                    <input id="sub-sub-group-3" type="checkbox" hidden="">
                    <label for="sub-sub-group-3">
                        <span>
                            <svg class="svg-icon" viewBox="0 0 20 20">
                                <path fill="none" d="M11.611,10.049l-4.76-4.873c-0.303-0.31-0.297-0.804,0.012-1.105c0.309-0.304,0.803-0.293,1.105,0.012l5.306,5.433c0.304,0.31,0.296,0.805-0.012,1.105L7.83,15.928c-0.152,0.148-0.35,0.223-0.547,0.223c-0.203,0-0.406-0.08-0.559-0.236c-0.303-0.309-0.295-0.803,0.012-1.104L11.611,10.049z"></path>
                            </svg>
                        </span>
                        Third level
                    </label>
                    <ul class="sub-sub-menu-list">
                        <li><a href="#">3rd level nav item</a></li>
                        <li><a href="#">3rd level nav item</a></li>
                        <li><a href="#">3rd level nav item</a></li>
                    </ul>
                </li>
            </ul>

        </ul>
    </li>
</ul>
</div>

</aside>
