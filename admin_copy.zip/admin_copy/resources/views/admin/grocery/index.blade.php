@extends('admin.grocery.template')
@section('content')
	<div style="padding: 0 20px;">
		{!! $output !!}
	</div>
@endsection
